# Basic-banking-system
this is a basic banking system, credit transfer between two users without any login page.
